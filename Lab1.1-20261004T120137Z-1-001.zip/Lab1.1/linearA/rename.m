% 1. ค้นหาไฟล์ .mat ทั้งหมดในโฟลเดอร์ปัจจุบันที่มีรูปแบบชื่อ realtime
mat_files = dir('*cm*.mat');

% 2. วนลูปแก้ไขทีละไฟล์
for k = 1:length(mat_files)
    filename = mat_files(k).name;
    file_content = load(filename);

    % ตรวจสอบว่าในไฟล์มีตัวแปร data หรือไม่
    if isfield(file_content, 'data')
        data = file_content.data;

        % ตรวจสอบว่ามีสัญญาณครบ 3 สัญญาณ
        if data.numElements >= 3
            % เปลี่ยนชื่อสัญญาณที่ 1 เป็น A0
            sig1 = data{1};
            sig1.Name = 'A0';
            data{1} = sig1;

            % เปลี่ยนชื่อสัญญาณที่ 2 เป็น Vout
            sig2 = data{2};
            sig2.Name = 'Vout';
            data{2} = sig2;

            % เปลี่ยนชื่อสัญญาณที่ 3 เป็น Trig
            sig3 = data{3};
            sig3.Name = 'Trig';
            data{3} = sig3;

            % บันทึกตัวแปร data ทับลงในไฟล์เดิม
            save(filename, 'data');
            fprintf('แก้ไขชื่อตัวแปรในไฟล์ %s เรียบร้อยแล้ว\n', filename);
        end
    end
end

disp('--- ดำเนินการอัปเดตครบทุกไฟล์เรียบร้อย ---');