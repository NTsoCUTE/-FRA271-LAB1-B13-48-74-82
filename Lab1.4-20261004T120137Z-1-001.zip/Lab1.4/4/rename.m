% 1. ค้นหาไฟล์ .mat ทั้งหมดในโฟลเดอร์ปัจจุบัน
mat_files = dir('*.mat'); 

% 2. วนลูปแก้ไขทีละไฟล์
for k = 1:length(mat_files)
    filename = mat_files(k).name;
    file_content = load(filename);

    % ตรวจสอบว่าในไฟล์มีตัวแปร data หรือไม่
    if isfield(file_content, 'data')
        data = file_content.data;

        % ตรวจสอบว่าเป็น Dataset และมีสัญญาณอย่างน้อย 2 ตัว
        if isa(data, 'Simulink.SimulationData.Dataset') && data.numElements >= 2
            % ดึงและเปลี่ยนชื่อสัญญาณที่ 1 เป็น A0
            sig1 = data{1};
            sig1.Name = 'A0';
            data = data.setElement(1, sig1);

            % ดึงและเปลี่ยนชื่อสัญญาณที่ 2 เป็น Vout
            sig2 = data{2};
            sig2.Name = 'Vout';
            data = data.setElement(2, sig2);

            % บันทึกตัวแปร data ทับลงไฟล์เดิม
            save(filename, 'data');
            fprintf('แก้ไขชื่อตัวแปรในไฟล์ %s เป็น [A0, Vout] เรียบร้อยแล้ว\n', filename);
        end
    end
end
disp('--- ดำเนินการอัปเดตครบทุกไฟล์เรียบร้อย ---');
